/**
 * Buzz BD Agent — REST API Server
 * v1.0.0 | Express + SQLite WAL
 * 
 * Runs alongside OpenClaw gateway on port 3000
 * OpenClaw handles agent orchestration on 18789
 * This API exposes Buzz's capabilities for BaaS + Mobile App
 */

const express = require('express');
const cors = require('cors');
const { initDB } = require('./db');
const { apiKeyAuth } = require('./middleware/auth');
const { rateLimit } = require('./middleware/rateLimit');

// Route imports
const healthRoutes = require('./routes/health');
const agentRoutes = require('./routes/agents');
const pipelineRoutes = require('./routes/pipeline');
const costRoutes = require('./routes/costs');
const cronRoutes = require('./routes/crons');
// const scoringRoutes = require('./routes/scoring');     // Day 2
// const intelRoutes = require('./routes/intel');          // Week 3
// const twitterRoutes = require('./routes/twitter');      // Week 3
// const walletRoutes = require('./routes/wallets');       // Week 3
// const webhookRoutes = require('./routes/webhooks');     // Week 3

const app = express();
const PORT = process.env.BUZZ_API_PORT || 3000;

// ─── Middleware ───────────────────────────────────────
app.use(cors({
  origin: process.env.BUZZ_API_CORS_ORIGIN || '*',
  methods: ['GET', 'POST', 'PATCH', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-API-Key', 'X-402-Payment']
}));
app.use(express.json({ limit: '1mb' }));
app.use(rateLimit);

// ─── Public Routes (no auth) ─────────────────────────
app.use('/api/v1/health', healthRoutes);

// API info endpoint
app.get('/api/v1/info', (req, res) => {
  res.json({
    name: 'Buzz BD Agent API',
    version: '1.0.0',
    agent: 'Buzz by SolCex',
    architecture: '5 parallel sub-agents + orchestrator',
    sub_agents: ['scanner-agent', 'safety-agent', 'wallet-agent', 'social-agent', 'scorer-agent'],
    orchestrator_model: 'MiniMax M2.5',
    sub_agent_model: 'bankr/gpt-5-nano',
    llm_gateway: 'Bankr LLM Gateway (8 models)',
    intel_sources: '16/17 connected',
    cron_jobs: 40,
    documentation: 'https://github.com/buzzbysolcex/buzz-bd-agent',
    links: {
      solcex: 'https://solcex.cc',
      twitter: 'https://x.com/BuzzBySolCex',
      erc8004: { ethereum: '#25045', base: '#17483', anet: '#18709' }
    }
  });
});

// ─── Authenticated Routes ────────────────────────────
app.use('/api/v1/agents', apiKeyAuth, agentRoutes);
app.use('/api/v1/pipeline', apiKeyAuth, pipelineRoutes);
app.use('/api/v1/costs', apiKeyAuth, costRoutes);
app.use('/api/v1/crons', apiKeyAuth, cronRoutes);
app.use("/api/v1", apiKeyAuth, require("./routes/score"));
// app.use('/api/v1/intel', apiKeyAuth, intelRoutes);
// app.use('/api/v1/twitter', apiKeyAuth, twitterRoutes);
// app.use('/api/v1/wallets', apiKeyAuth, walletRoutes);
// app.use('/api/v1/webhooks', apiKeyAuth, webhookRoutes);

// ─── 404 Handler ─────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({
    error: 'not_found',
    message: `Route ${req.method} ${req.path} does not exist`,
    docs: '/api/v1/info'
  });
});

// ─── Error Handler ───────────────────────────────────
app.use((err, req, res, next) => {
  console.error(`[API ERROR] ${err.message}`, err.stack);
  res.status(err.status || 500).json({
    error: 'internal_error',
    message: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message
  });
});

// ─── Start ───────────────────────────────────────────
async function start() {
  try {
    await initDB();
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`[Buzz API] ✓ Running on port ${PORT}`);
      console.log(`[Buzz API] ✓ Health: http://0.0.0.0:${PORT}/api/v1/health`);
      console.log(`[Buzz API] ✓ Info:   http://0.0.0.0:${PORT}/api/v1/info`);
    });
  } catch (err) {
    console.error('[Buzz API] ✗ Failed to start:', err.message);
    process.exit(1);
  }
}

start();
